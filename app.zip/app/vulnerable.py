from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
import hashlib

app = Flask(__name__)
app.secret_key = 'dev-secret-key'
DB = 'vulnn.db'

@app.route('/')
def home():
    return render_template('Secure.html')

# صفحة التسجيل
@app.route('/signup', methods=['GET', 'POST'])
def signup_unsafe():
    if request.method == 'POST':
        data = request.form
        md5_pw = hashlib.md5(data['password'].encode()).hexdigest()
        try:
            with sqlite3.connect(DB) as conn:
                c = conn.cursor()
                c.execute("""
                    INSERT INTO users(full_name,nick_name,email,username,password,gender,country,language)
                    VALUES(?,?,?,?,?,?,?,?)
                """, (data['full_name'], data['nick_name'], data['email'], data['username'], md5_pw, data['gender'], data['country'], data['language']))
                conn.commit()
            flash('Account created successfully!', 'success')
            return redirect(url_for('login_unsafe'))
        except sqlite3.IntegrityError:
            flash('Username or Email already exists!', 'danger')
    return render_template('SignUp.html')

# صفحة تسجيل الدخول
@app.route('/login', methods=['GET', 'POST'])
def login_unsafe():
    if request.method == 'POST':
        email = request.form['email']
        raw_pw = request.form['password']

        # نفس التشفير المستخدم في signup
        pw = hashlib.md5(raw_pw.encode()).hexdigest()

        conn = sqlite3.connect(DB)
        c = conn.cursor()
        query = f"SELECT * FROM users WHERE email='{email}' AND password='{pw}'"
        c.execute(query)
        user = c.fetchone()
        conn.close()

        if user:
            session['user_id'] = user[0]          # هذا أهم سطر لتخزين الجلسة
            session['username'] = user[4]         # username
            session['email'] = user[3]            # email (اختياري)
            return redirect(url_for('dashboard_unsafe'))

        flash('Invalid credentials', 'danger')
    return render_template('loginSecure.html')

# صفحة الداشبورد
@app.route('/dashboard-unsafe')
def dashboard_unsafe():
    if 'user_id' not in session:
        print('Session missing user_id!')
        return redirect(url_for('login_unsafe'))

    print('Session user_id:', session['user_id'])
    print('Session username:', session.get('username'))

    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('SELECT content FROM comments WHERE user_id=?', (session['user_id'],))
    comments = [r[0] for r in c.fetchall()]
    conn.close()

    print('Comments:', comments)

    return render_template('DashboardS.html', comments=comments)

# صفحة الأدمن بدون حماية
@app.route('/admin_dashboard_open')
def admin_dashboard_open():
    return render_template('adminPage.html')
@app.route('/add_comment_unsafe', methods=['POST'])
def add_comment_unsafe():
    comment = request.form['comment']
    uid = session.get('user_id')

    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("INSERT INTO comments(user_id, content) VALUES(?, ?)", (uid, comment))
    conn.commit()
    conn.close()

    return redirect(url_for('dashboard_unsafe'))
if __name__ == '__main__':
    app.run(debug=True)