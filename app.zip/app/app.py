# secure_app.py
from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from markupsafe import escape
import os, ssl

app = Flask(__name__, template_folder='templates')
app.secret_key = os.urandom(24)

# ↓ إعدادات الأمان للكوكيز
app.config.update(
    SESSION_COOKIE_SECURE=True,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax'
)

DB = 'vuln.db'  # أو غيّره إلى secure.db إذا حاب

def init_db():
    if not os.path.exists(DB):
        conn = sqlite3.connect(DB); c = conn.cursor()
        c.execute('''
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                email TEXT UNIQUE,
                password TEXT,
                role TEXT DEFAULT 'user'
            )
        ''')
        c.execute('''
            CREATE TABLE comments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                content TEXT
            )
        ''')
        conn.commit(); conn.close()

init_db()

# ——— الصفحة الرئيسية ———
@app.route('/')
def home():
    # Secure.html: صفحة ترحيبية مع روابط Sign Up و Login
    return render_template('Secure.html')


# ——— Sign Up آمن ———
@app.route('/signup', methods=['GET','POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        email    = request.form['email']
        raw_pw   = request.form['password']
        # تخزين آمن: bcrypt + salt
        hashed_pw = generate_password_hash(raw_pw)

        conn = sqlite3.connect(DB); c = conn.cursor()
        try:
            c.execute(
                'INSERT INTO users(username,email,password) VALUES(?,?,?)',
                (username, email, hashed_pw)
            )
            conn.commit()
            flash('Account created successfully!', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Username or Email already exists!', 'danger')
        finally:
            conn.close()

    return render_template('SignUp.html')


# ——— Login آمن + حماية من SQL Injection ———
@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email  = request.form['email']
        raw_pw = request.form['password']

        conn = sqlite3.connect(DB); c = conn.cursor()
        # استعلام محضَّر يقي من SQL Injection
        c.execute(
            'SELECT id, username, password, role FROM users WHERE email = ?',
            (email,)
        )
        user = c.fetchone()
        conn.close()

        if user and check_password_hash(user[2], raw_pw):
            session['user_id'] = user[0]
            session['username'] = user[1]
            session['role'] = user[3]
            flash('Logged in successfully!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials.', 'danger')

    return render_template('loginSecure.html')


# ——— Dashboard مع حماية XSS ———
@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect(DB); c = conn.cursor()
    c.execute('SELECT content FROM comments')
    comments = [r[0] for r in c.fetchall()]
    conn.close()

    # DashboardS.html يجب أن يعرض {{ username }} و-loop على {{ comments }}
    return render_template(
        'DashboardS.html',
        username=session.get('username'),
        comments=comments
    )


@app.route('/add_comment', methods=['POST'])
def add_comment():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    # ترشيح مدخل المستخدم لحماية من XSS
    raw = request.form['comment']
    clean = escape(raw)

    conn = sqlite3.connect(DB); c = conn.cursor()
    c.execute(
        'INSERT INTO comments(user_id, content) VALUES(?,?)',
        (session['user_id'], clean)
    )
    conn.commit(); conn.close()

    flash('Comment added!', 'success')
    return redirect(url_for('dashboard'))


# ——— لوحة الأدمن مع RBAC ———
@app.route('/admin_dashboard')
def admin_dashboard():
    if session.get('role') != 'admin':
        flash('Access Denied! Admins only.', 'danger')
        return redirect(url_for('dashboard'))
    # adminPage.html يعرض محتوى الأدمن
    return render_template('adminPage.html')


if __name__ == '__main__':
    # لإنشاء شهادة ذاتية التوقيع (مرة واحدة خارج الكود):
    #   openssl req -x509 -newkey rsa:2048 -nodes -keyout key.pem -out cert.pem -days 365
    context = ssl.SSLContext(ssl.PROTOCOL_TLS)
    context.load_cert_chain('cert.pem', 'key.pem')
    app.run(host='0.0.0.0', port=5001, ssl_context=context)