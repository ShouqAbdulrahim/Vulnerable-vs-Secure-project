import sqlite3

conn = sqlite3.connect('vulnn.db')
c = conn.cursor()

# إنشاء جدول users
c.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        full_name TEXT,
        nick_name TEXT,
        email TEXT UNIQUE,
        username TEXT UNIQUE,
        password TEXT,
        gender TEXT,
        country TEXT,
        language TEXT,
        role TEXT DEFAULT 'user'
    )
''')

# إنشاء جدول comments
c.execute('''
    CREATE TABLE IF NOT EXISTS comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        content TEXT
    )
''')

conn.commit()
conn.close()