# secure_app.py
from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from markupsafe import escape
import os, ssl

app = Flask(__name__, template_folder='templates')
app.secret_key = os.urandom(24)

app.config.update(
    SESSION_COOKIE_SECURE=True,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax'
)

DB = 'vulnn.db'

def init_db():
    if not os.path.exists(DB):
        conn = sqlite3.connect(DB); c = conn.cursor()
        c.execute('''
        CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        full_name TEXT,
        nick_name TEXT,
        email TEXT UNIQUE,
        username TEXT UNIQUE,
        password TEXT,
        gender TEXT,
        country TEXT,
        language TEXT,
        role TEXT DEFAULT 'user'
        )
     ''')
        c.execute('''
            CREATE TABLE comments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                content TEXT
            )
        ''')
        conn.commit(); conn.close()

init_db()

@app.route('/')
def home():
   
    return render_template('Secure.html')



@app.route('/signup', methods=['GET', 'POST'])
def signup_unsafe():
    if request.method == 'POST':
        data = request.form
        hashed = generate_password_hash(data['password'])  # Fixed hash 

        try:
            with sqlite3.connect(DB) as conn:
                c = conn.cursor()
                c.execute("""
                    INSERT INTO users(full_name,nick_name,email,username,password,gender,country,language, role)
                    VALUES(?,?,?,?,?,?,?,?,?)
                """, (data['full_name'], data['nick_name'], data['email'], data['username'], hashed, data['gender'], data['country'], data['language'], 'user'))
                conn.commit()
            flash('Account created successfully!', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Username or Email already exists!', 'danger')
    return render_template('SignUp.html')



@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email  = request.form['email']
        raw_pw = request.form['password']

        conn = sqlite3.connect(DB); c = conn.cursor()
       
        c.execute(
            'SELECT id, username, password, role FROM users WHERE email = ?',
            (email,)
        )
        user = c.fetchone()
        conn.close()

        if user and check_password_hash(user[2], raw_pw):
            session['user_id'] = user[0]
            session['username'] = user[1]
            session['role'] = user[3]
            flash('Logged in successfully!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials.', 'danger')

    return render_template('loginSecure.html')



@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect(DB); c = conn.cursor()
    c.execute('SELECT content FROM comments')
    comments = [r[0] for r in c.fetchall()]
    conn.close()

    return render_template(
        'DashboardS.html',
        username=session.get('username'),
        comments=comments
    )


@app.route('/add_comment', methods=['POST'])
def add_comment():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    raw = request.form['comment']
    clean = escape(raw)

    conn = sqlite3.connect(DB); c = conn.cursor()
    c.execute(
        'INSERT INTO comments(user_id, content) VALUES(?,?)',
        (session['user_id'], clean)
    )
    conn.commit(); conn.close()

    flash('Comment added!', 'success')
    return redirect(url_for('dashboard'))


@app.route('/admin_dashboard_open')
def admin_dashboard_open():
   
    if 'user_id' not in session:
        flash('You need to log in first.', 'danger')
        return redirect(url_for('login'))


    if session.get('role') != 'admin':
        flash('Only admins can access this page.', 'danger')
        return redirect(url_for('dashboard'))

    return render_template('adminPage.html')

if __name__ == '__main__':
  
    #   openssl req -x509 -newkey rsa:2048 -nodes -keyout key.pem -out cert.pem -days 365
    context = ssl.SSLContext(ssl.PROTOCOL_TLS)
    context.load_cert_chain('cert.pem', 'key.pem')
    app.run(host='0.0.0.0', port=5001, ssl_context=context)