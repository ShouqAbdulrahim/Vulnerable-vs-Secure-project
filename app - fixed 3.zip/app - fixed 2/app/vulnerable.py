from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
import hashlib
import bcrypt  # Secure password hashing

app = Flask(__name__)
app.secret_key = 'dev-secret-key'
DB = 'vulnn.db'

@app.route('/')
def home():
    return render_template('Secure.html')

# Registration page
@app.route('/signup', methods=['GET', 'POST'])
def signup_unsafe():
    if request.method == 'POST':
        data = request.form
        hashed_pw = bcrypt.hashpw(data['password'].encode(), bcrypt.gensalt())

        try:
            with sqlite3.connect(DB) as conn:
                c = conn.cursor()
                c.execute("""
                    INSERT INTO users(full_name, nick_name, email, username, password, gender, country, language)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (data['full_name'], data['nick_name'], data['email'], data['username'],
                      hashed_pw, data['gender'], data['country'], data['language']))
                conn.commit()
            flash('Account created successfully!', 'success')
            return redirect(url_for('login_unsafe'))
        except sqlite3.IntegrityError:
            flash('Username or Email already exists!', 'danger')
    return render_template('SignUp.html')

# Login page
@app.route('/login', methods=['GET', 'POST'])
def login_unsafe():
    if request.method == 'POST':
        email = request.form['email']
        raw_pw = request.form['password']

        conn = sqlite3.connect(DB)
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE email=?", (email,))
        user = c.fetchone()
        conn.close()

        if user and bcrypt.checkpw(raw_pw.encode(), user[5]):
            session['user_id'] = user[0]
            session['username'] = user[4]
            session['email'] = user[3]
            return redirect(url_for('dashboard_unsafe'))

        flash('Invalid credentials', 'danger')

    return render_template('loginSecure.html')

# Dashboard page
@app.route('/dashboard-unsafe')
def dashboard_unsafe():
    if 'user_id' not in session:
        print('Session missing user_id!')
        return redirect(url_for('login_unsafe'))

    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('SELECT content FROM comments WHERE user_id=?', (session['user_id'],))
    comments = [r[0] for r in c.fetchall()]
    conn.close()

    return render_template('DashboardS.html', comments=comments)

# Admin page (not protected)
@app.route('/admin_dashboard_open')
def admin_dashboard_open():
    return render_template('adminPage.html')

# Add comment (initially vulnerable to XSS unless escaped in template)
@app.route('/add_comment_unsafe', methods=['POST'])
def add_comment_unsafe():
    comment = request.form['comment']
    uid = session.get('user_id')

    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("INSERT INTO comments(user_id, content) VALUES(?, ?)", (uid, comment))
    conn.commit()
    conn.close()

    return redirect(url_for('dashboard_unsafe'))

if __name__ == '__main__':
    app.run(debug=True)
